$(function() {
	$('#imgcycle').cycle({
		fx:     'fade',
		speed:   300,
		next:   '#imgcycle',
		timeout: 4000,
		pause:   1
	});
});
