<!-- start for fancy folding/unfolding -->		
		
<!--[if lte IE 6]>
<style type="text/css">
h3 a, .demo {position:relative; height:1%}
</style>
--> 
<![endif]--> 
 
<!--[if lte IE 6]>
<script type="text/javascript">
   try { document.execCommand( "BackgroundImageCache", false, true); } catch(e) {};
</script>
<![endif]--> 
<!--[if !lt IE 6]><!--> 
//<script type="text/javascript" src="scripts/jquery.min.js"></script> 
<script type="text/javascript" src="scripts/expand.js"></script> 
<script type="text/javascript"> 
<!--//--><![CDATA[//><!--
$(function() {
    $("dt.expand").toggler();
//    $("div.demo").expandAll({trigger: "dt.expand", ref: "dt.expand"});
//    $("#content div.other").expandAll({
//      expTxt : "[Show]", 
//      cllpsTxt : "[Hide]",
//      ref : "ul.collapse",
//      showMethod : "show",
//      hideMethod : "hide"
//    });
//    $("#content div.post").expandAll({
//      expTxt : "[Read this entry]", 
//      cllpsTxt : "[Hide this entry]",
//      ref : "div.collapse", 
//      localLinks: "p.top a"    
//    });    
});
//--><!]]>
</script> 
<!--<![endif]--> 
<!-- end scripts for fancy folding/unfolding -->		
